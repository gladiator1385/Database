//"�ﷸ������ť�ļ�����"


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;


public class AllCriminalListener implements ActionListener{
	Connection conn_;
	JTable table_;
	String []columnName;
	String [][]record;
	
	void setConnection(Connection conn) {
		conn_=conn;
	}
	
    public void actionPerformed(ActionEvent f) {
    	Statement sql;
    	ResultSet rs;
    	try {
    	    sql=conn_.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
    	    rs=sql.executeQuery("select * from criminals order by criminal_id");
    	    ResultSetMetaData metaData=rs.getMetaData();
    	    int columnCount=metaData.getColumnCount(); 
    	    columnName=new String[columnCount];
    	    for(int i=1;i<=columnCount;i++) {
    	    	columnName[i-1]=metaData.getColumnName(i);
    	    }
    	    rs.last();
    	    int recordAmount=rs.getRow();
    	    record=new String[recordAmount][columnCount];
    	    rs.beforeFirst();
    	    int i=0;
    	    while(rs.next()) {
    	    	for(int j=1;j<=columnCount;j++) {
    	    		record[i][j-1]=rs.getString(j);
    	    	}
    	    	i++;
    	    }
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
	    table_=new JTable(record,columnName);
	    JFrame subWindow=new JFrame();
	    subWindow.add(new JScrollPane(table_));
	    subWindow.setBounds(550,450,500,200);
	    subWindow.setVisible(true);
    }
}