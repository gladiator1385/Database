import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.sql.Connection;

public class MainWindow extends JFrame {
	public MainWindow(Connection conn_) {
		setTitle("Criminal information management system");
		setLayout(null);
		
		
		setBounds(500,250,750,500);
	    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    
	    JLabel all_criminal=new JLabel("Summary of Criminals��");
	    JButton all_criminal_show=new JButton("Inquire");
	    all_criminal.setBounds(5,5,140,30);
	    all_criminal_show.setBounds(150,5,50,30);
	    all_criminal_show.setMargin(new Insets(0,0,0,0));
	    add(all_criminal);
	    add(all_criminal_show);
	    
	    JLabel all_case=new JLabel("Summary of Cases��");
	    JButton all_case_show=new JButton("Inquire");
	    all_case.setBounds(205,5,120,30);
	    all_case_show.setBounds(330,5,50,30);
	    all_case_show.setMargin(new Insets(0,0,0,0));
	    add(all_case);
	    add(all_case_show);

	    JLabel all_crime=new JLabel("Summary of Crimes��");
	    JButton all_crime_show=new JButton("Inquire");
	    all_crime.setBounds(385,5,125,30);
	    all_crime_show.setBounds(515,5,50,30);
	    all_crime_show.setMargin(new Insets(0,0,0,0));
	    add(all_crime);
	    add(all_crime_show);
	    
	    JLabel crime_name=new JLabel("Crime Name��");
	    JTextField enter_crime_name=new JTextField();
	    JButton crime_name_registered=new JButton("Enter");
	    crime_name.setBounds(5,40,100,30);
	    enter_crime_name.setBounds(110,40,120,30);
	    crime_name_registered.setBounds(235,40,50,30);
	    crime_name_registered.setMargin(new Insets(0,0,0,0));
	    add(crime_name);
	    add(enter_crime_name);
	    add(crime_name_registered);

	    JLabel id_label=new JLabel("Criminal id:");
	    JTextField id_field=new JTextField();
	    JLabel crime_label=new JLabel("Crime id:");
	    JTextField enter_crime=new JTextField();
	    JLabel term_label=new JLabel("Term(days):");
	    JTextField enter_term=new JTextField();
	    JLabel name_label=new JLabel("Criminal Name:");
	    JTextField enter_name=new JTextField();
	    JLabel hometown_label=new JLabel("Hometown:");
	    JTextField enter_hometown=new JTextField();
	    JButton case_registered=new JButton("Enter the case");
	    JLabel hint_drop=new JLabel("Delete case by case id:");
	    JTextField enter_case_id=new JTextField();
	    JButton drop_button=new JButton("Delete");
	    id_label.setBounds(5,75,70,30);
	    id_field.setBounds(80,75,120,30);
	    crime_label.setBounds(205,75,70,30);
	    enter_crime.setBounds(280,75,120,30);
	    term_label.setBounds(405,75,70,30);
	    enter_term.setBounds(480,75,40,30);
	    name_label.setBounds(5,110,110,30);
	    enter_name.setBounds(120,110,120,30);
	    hometown_label.setBounds(245,110,80,30);
	    enter_hometown.setBounds(330,110,120,30);
	    case_registered.setBounds(455,110,110,30);
	    case_registered.setMargin(new Insets(0,0,0,0));
	    hint_drop.setBounds(5,145,150,30);
	    enter_case_id.setBounds(160,145,120,30);
	    drop_button.setBounds(285,145,50,30);
	    drop_button.setMargin(new Insets(0,0,0,0));
        JLabel crime_id_alter=new JLabel("Criminal id:");
        JTextField enter_id_alter=new JTextField();
        JLabel crime_hometown_alter=new JLabel("New Hometown:");
        JTextField enter_hometown_alter=new JTextField();
        JButton goAlterHometown=new JButton("Modify the hometown of the Criminal");
        crime_id_alter.setBounds(5,180,70,30);
        enter_id_alter.setBounds(80,180,120,30);
        crime_hometown_alter.setBounds(205,180,110,30);
        enter_hometown_alter.setBounds(320,180,120,30);
        goAlterHometown.setBounds(445,180,230,30);
        goAlterHometown.setMargin(new Insets(0,0,0,0));
        add(crime_id_alter);
        add(enter_id_alter);
        add(crime_hometown_alter);
        add(enter_hometown_alter);
        add(goAlterHometown);
	    add(id_label);
	    add(id_field);
	    add(crime_label);
	    add(enter_crime);
	    add(term_label);
	    add(enter_term);
	    add(name_label);
	    add(enter_name);
	    add(hometown_label);
	    add(enter_hometown);
	    add(case_registered);
	    add(hint_drop);
	    add(enter_case_id);
	    add(drop_button);
	    
	    
	    AllCrimeListener all_crime_listener=new AllCrimeListener();
	    all_crime_listener.setConnection(conn_);
	    all_crime_show.addActionListener(all_crime_listener);
	    
	    AllCriminalListener all_criminal_listener=new AllCriminalListener();
	    all_criminal_listener.setConnection(conn_);
	    all_criminal_show.addActionListener(all_criminal_listener);
	    
	    AllCaseListener all_case_listener=new AllCaseListener();
	    all_case_listener.setConnection(conn_);
	    all_case_show.addActionListener(all_case_listener);
	    
	    AddCrimeListener add_crime_listener=new AddCrimeListener();
	    add_crime_listener.set_fields(enter_crime_name);
	    add_crime_listener.setParent(this);
	    add_crime_listener.setConnection(conn_);
	    crime_name_registered.addActionListener(add_crime_listener);
	
	    AddCaseListener add_case_listener=new AddCaseListener();
	    add_case_listener.set_fields(id_field,enter_crime,enter_name,enter_hometown,enter_term);
	    add_case_listener.setParent(this);
	    add_case_listener.setConnection(conn_);
	    case_registered.addActionListener(add_case_listener);
	    
	    DeleteCaseListener delete_case_listener=new DeleteCaseListener();
	    delete_case_listener.set_fields(enter_case_id);
	    delete_case_listener.setParent(this);
	    delete_case_listener.setConnection(conn_);
	    drop_button.addActionListener(delete_case_listener);
	    
	    AlterHometown alter_hometown=new AlterHometown();
	    alter_hometown.set_fields(enter_id_alter,enter_hometown_alter);
	    alter_hometown.setParent(this);
	    alter_hometown.setConnection(conn_);
	    goAlterHometown.addActionListener(alter_hometown);
	    
	    
	}
}