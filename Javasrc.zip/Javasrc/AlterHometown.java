//"�޸��ﷸ����ļ�����"


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;


public class AlterHometown implements ActionListener{
    JTextField F1,F2;
    Connection conn_;
    JFrame parent_;
    
    void set_fields(JTextField a,JTextField b) {
    	F1=a;
    	F2=b;
    }
    
    void setConnection(Connection conn) {
    	conn_=conn;
    }
    
    void setParent(JFrame p) {
    	parent_=p;
    }
    
    public void actionPerformed(ActionEvent f) {
    	Statement sql;
    	try {
    		sql=conn_.createStatement();
    		sql.executeUpdate("update criminals set hometown= '"+F2.getText()+"' where criminal_id= '"+F1.getText()+"';");
    		JOptionPane.showMessageDialog(parent_, "Successfully��","Status",1);
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
}